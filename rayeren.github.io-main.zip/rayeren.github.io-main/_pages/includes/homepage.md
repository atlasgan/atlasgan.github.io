# 📎 Homepages
- Personal Pages: https://rayeren.github.io (updated recently🔥)
- Linkedin: https://www.linkedin.com/in/rayeren
- Google Scholar: https://scholar.google.com/citations?user=4FA6C0AAAAAJ
- DBLP: https://dblp.org/pid/75/6568-6.html
